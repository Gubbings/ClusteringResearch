#include <iostream>
#include <string>
#include <stdlib.h>
#include "LocalSearchClustering.h"

using namespace std;

int main(int argc, char *argv[]) {

	string in = "in.txt";
	string clusters = "in.cluster";
	string out = "out.txt";
	
	if (argc != 5) {
		cout << "Arguments not properly specified using defaults. " << endl;
		cout << "Expected arguments 1: graph file, 2: cluster file, 3: output file" << endl;
		cout << "Default settings: \ngraph file = in.txt, \nclusters file = in.clsuter, \noutput file = out.txt" << endl;
	}
	else {
		in = argv[1];
		clusters = argv[2];
		out = argv[3];		
	}
	
	
	LocalSearchClustering localSearchAlg(in, clusters, out);
	localSearchAlg.beginClustering();
	

	return 0;
}

